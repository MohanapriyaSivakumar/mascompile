#!/usr/bin/env python
# coding: utf-8

# # Boolean
# 
# ![](../images/bool.jpg)
# a Boolean can be either True or False
# 

# In[1]:


1==1 #checks both are equal or not


# In[2]:


1==0


# ### converts to boolean if anything presents insice the quotes its returns true otherwise false

# In[3]:


bool("asdasd") 


# In[4]:


bool(" ") #contains space


# In[5]:


bool("") # contains nothing


# In[6]:


bool(0)


# In[7]:


bool(34)

