#!/usr/bin/env python
# coding: utf-8

# # Lines and Indention
# 
# No braces need for blocks of code for class & function definition or flow control
# The number of spaces in the indention is variable but all the statements within the block must be same indent.
# 
# ### For example
# 

# In[1]:


a=20
b=40
if(a>b):
    print("true")
else:
    print("false")


# ![](images/indent.png)

# In[ ]:




